t=open('/root/doom/page/template.html').read()
engines=[open('/root/doom/build/doom.js').read()]+[open('/root/doom/build2/out/%s.js'%g).read() for g in ('heretic','hexen','strife')]
for e in engines: assert '</script' not in e.lower()
frag=t.replace('/*__ENGINES__*/', '\n'.join(engines))
open('/root/doom/page/doom2-artifact.html','w').write(frag)
head_end = frag.index('</style>')+len('</style>')
full='<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'+frag[:head_end]+'\n</head>\n<body>\n'+frag[head_end:]+'\n</body>\n</html>\n'
open('/root/doom/page/doom2.html','w').write(full)
print(len(full))
