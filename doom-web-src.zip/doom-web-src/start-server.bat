@echo off
rem Double-click to play: serves this folder and opens the page.
cd /d "%~dp0"
where py >nul 2>nul && (py -3 serve.py & goto :eof)
where python >nul 2>nul && (python serve.py & goto :eof)
echo Python 3 is needed. Install it from https://www.python.org/downloads/ and try again.
pause
