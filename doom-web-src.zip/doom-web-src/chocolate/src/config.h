#define PACKAGE_NAME "Chocolate Doom"
#define PACKAGE_TARNAME "chocolate-doom"
#define PACKAGE_VERSION "3.0.1"
#define PACKAGE_STRING "Chocolate Doom 3.0.1"
#define PROGRAM_PREFIX "chocolate-"
#define HAVE_DECL_STRCASECMP 1
#define HAVE_DECL_STRNCASECMP 1
