// OPL driver for the single-threaded browser build.
// Adapted from Chocolate Doom's opl_sdl.c (GPLv2). Instead of an SDL
// audio callback, the page's audio callback calls OPL_Web_Render().

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "opl3.h"
#include "opl.h"
#include "opl_internal.h"
#include "opl_queue.h"

typedef struct
{
    unsigned int rate;
    unsigned int enabled;
    unsigned int value;
    uint64_t expire_time;
} opl_timer_t;

static opl_callback_queue_t *callback_queue = NULL;
static uint64_t current_time;
static int opl_web_paused;
static uint64_t pause_offset;
static opl3_chip opl_chip;
static int opl_opl3mode;
static int register_num = 0;
static opl_timer_t timer1 = { 12500, 0, 0, 0 };
static opl_timer_t timer2 = { 3125, 0, 0, 0 };
static int mixing_freq = 44100;
static int initialized = 0;

static void AdvanceTimeUs(uint64_t us)
{
    opl_callback_t callback;
    void *callback_data;

    current_time += us;
    if (opl_web_paused)
    {
        pause_offset += us;
    }

    while (!OPL_Queue_IsEmpty(callback_queue)
        && current_time >= OPL_Queue_Peek(callback_queue) + pause_offset)
    {
        if (!OPL_Queue_Pop(callback_queue, &callback, &callback_data))
        {
            break;
        }
        callback(callback_data);
    }
}

void OPL_Web_Delay(uint64_t us)
{
    if (initialized)
    {
        AdvanceTimeUs(us);
    }
}

// Fill `buffer` with `buffer_len` stereo frames of interleaved int16.
void OPL_Web_Render(int16_t *buffer, unsigned int buffer_len)
{
    unsigned int filled = 0;

    if (!initialized)
    {
        memset(buffer, 0, buffer_len * 4);
        return;
    }

    while (filled < buffer_len)
    {
        uint64_t next_callback_time;
        uint64_t nsamples;

        if (opl_web_paused || OPL_Queue_IsEmpty(callback_queue))
        {
            nsamples = buffer_len - filled;
        }
        else
        {
            next_callback_time = OPL_Queue_Peek(callback_queue) + pause_offset;
            if (next_callback_time <= current_time)
            {
                nsamples = 0;
            }
            else
            {
                nsamples = (next_callback_time - current_time) * mixing_freq;
                nsamples = (nsamples + OPL_SECOND - 1) / OPL_SECOND;
            }
            if (nsamples > buffer_len - filled)
            {
                nsamples = buffer_len - filled;
            }
        }

        if (nsamples > 0)
        {
            OPL3_GenerateStream(&opl_chip, buffer + filled * 2, nsamples);
            filled += nsamples;
        }

        AdvanceTimeUs((nsamples * OPL_SECOND) / mixing_freq);
    }
}

static void OPL_Web_Shutdown(void)
{
    if (initialized)
    {
        OPL_Queue_Destroy(callback_queue);
        callback_queue = NULL;
        initialized = 0;
    }
}

static int OPL_Web_Init(unsigned int port_base)
{
    opl_web_paused = 0;
    pause_offset = 0;
    callback_queue = OPL_Queue_Create();
    current_time = 0;
    mixing_freq = opl_sample_rate;
    OPL3_Reset(&opl_chip, mixing_freq);
    opl_opl3mode = 0;
    initialized = 1;
    return 1;
}

static unsigned int OPL_Web_PortRead(opl_port_t port)
{
    unsigned int result = 0;

    if (port == OPL_REGISTER_PORT_OPL3)
    {
        return 0xff;
    }

    if (timer1.enabled && current_time > timer1.expire_time)
    {
        result |= 0x80;
        result |= 0x40;
    }

    if (timer2.enabled && current_time > timer2.expire_time)
    {
        result |= 0x80;
        result |= 0x20;
    }

    return result;
}

static void OPLTimer_CalculateEndTime(opl_timer_t *timer)
{
    int tics;

    if (timer->enabled)
    {
        tics = 0x100 - timer->value;
        timer->expire_time = current_time
                           + ((uint64_t) tics * OPL_SECOND) / timer->rate;
    }
}

static void WriteRegister(unsigned int reg_num, unsigned int value)
{
    switch (reg_num)
    {
        case OPL_REG_TIMER1:
            timer1.value = value;
            OPLTimer_CalculateEndTime(&timer1);
            break;

        case OPL_REG_TIMER2:
            timer2.value = value;
            OPLTimer_CalculateEndTime(&timer2);
            break;

        case OPL_REG_TIMER_CTRL:
            if (value & 0x80)
            {
                timer1.enabled = 0;
                timer2.enabled = 0;
            }
            else
            {
                if ((value & 0x40) == 0)
                {
                    timer1.enabled = (value & 0x01) != 0;
                    OPLTimer_CalculateEndTime(&timer1);
                }

                if ((value & 0x20) == 0)
                {
                    timer2.enabled = (value & 0x02) != 0;
                    OPLTimer_CalculateEndTime(&timer2);
                }
            }
            break;

        case OPL_REG_NEW:
            opl_opl3mode = value & 0x01;
            // fall through

        default:
            OPL3_WriteRegBuffered(&opl_chip, reg_num, value);
            break;
    }
}

static void OPL_Web_PortWrite(opl_port_t port, unsigned int value)
{
    if (port == OPL_REGISTER_PORT)
    {
        register_num = value;
    }
    else if (port == OPL_REGISTER_PORT_OPL3)
    {
        register_num = value | 0x100;
    }
    else if (port == OPL_DATA_PORT)
    {
        WriteRegister(register_num, value);
    }
}

static void OPL_Web_SetCallback(uint64_t us, opl_callback_t callback,
                                void *data)
{
    OPL_Queue_Push(callback_queue, callback, data,
                   current_time - pause_offset + us);
}

static void OPL_Web_ClearCallbacks(void)
{
    OPL_Queue_Clear(callback_queue);
}

static void OPL_Web_Lock(void)
{
}

static void OPL_Web_Unlock(void)
{
}

static void OPL_Web_SetPaused(int paused)
{
    opl_web_paused = paused;
}

static void OPL_Web_AdjustCallbacks(float factor)
{
    OPL_Queue_AdjustCallbacks(callback_queue, current_time, factor);
}

opl_driver_t opl_web_driver =
{
    "Web",
    OPL_Web_Init,
    OPL_Web_Shutdown,
    OPL_Web_PortRead,
    OPL_Web_PortWrite,
    OPL_Web_SetCallback,
    OPL_Web_ClearCallbacks,
    OPL_Web_Lock,
    OPL_Web_Unlock,
    OPL_Web_SetPaused,
    OPL_Web_AdjustCallbacks,
};
