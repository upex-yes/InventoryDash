#!/bin/bash
# Compile common + per-game objects for the Chocolate engines.
cd ~/doom/build2
CF="-O2 -w -I src -I opl -I web/fake -I web"
mkdir -p obj/common obj/heretic obj/hexen obj/strife
fail=0
build() { # out src extra
  if [ ! -f "$1" ] || [ "$2" -nt "$1" ]; then
    emcc $CF $3 -c "$2" -o "$1" 2> "$1.err" || { echo "FAIL $2"; head -8 "$1.err"; fail=1; }
  fi
}
for f in src/*.c opl/*.c web/web_video.c web/web_sound.c web/txt_stub.c; do
  b=$(basename $f .c); build obj/common/$b.o $f ""
done
for g in heretic hexen strife; do
  G=$(echo $g | tr a-z A-Z)
  for f in src/$g/*.c; do b=$(basename $f .c); build obj/$g/$b.o $f "-I src/$g"; done
  build obj/$g/web_platform.o web/web_platform.c "-I src/$g -DWEB_GAME_$G"
done
exit $fail
