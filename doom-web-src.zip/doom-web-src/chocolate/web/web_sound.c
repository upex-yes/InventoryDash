// Browser sound module: mixes DMX sound effects and OPL (AdLib) music
// into one stereo int16 buffer that the page pulls via web_audio_render().

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <emscripten.h>

#include "doomtype.h"
#include "i_sound.h"
#include "m_misc.h"
#include "w_wad.h"
#include "z_zone.h"
#include "deh_str.h"

#include <math.h>

// Config variables normally owned by the SDL sound/music modules.
int use_libsamplerate = 0;
float libsamplerate_scale = 0.65f;
char *music_pack_path = "";
char *timidity_cfg_path = "";
void I_InitTimidityConfig(void) {}

extern music_module_t music_opl_module;
void OPL_Web_Render(int16_t *buffer, unsigned int buffer_len);

#define NUM_CHANNELS 16

typedef struct
{
    const byte *samples;   // unsigned 8-bit PCM
    uint32_t length;       // number of samples
    uint32_t rate;
} sfx_data_t;

typedef struct
{
    const sfx_data_t *sfx;
    uint64_t pos;          // 32.32 fixed point position
    uint64_t step;
    int lvol, rvol;        // 0..256
    int active;
} channel_t;

static channel_t channels[NUM_CHANNELS];
static int output_rate = 44100;
static boolean use_sfx_prefix;
static boolean sound_ok = false;
static boolean music_ok = false;
static int32_t *mixbuf = NULL;
static int mixbuf_len = 0;

EMSCRIPTEN_KEEPALIVE void web_set_samplerate(int rate)
{
    output_rate = rate;
    snd_samplerate = rate;
}

static void GetSfxLumpName(sfxinfo_t *sfx, char *buf, size_t buf_len)
{
    if (sfx->link != NULL)
    {
        sfx = sfx->link;
    }

    if (use_sfx_prefix)
    {
        M_snprintf(buf, buf_len, "ds%s", DEH_String(sfx->name));
    }
    else
    {
        M_StringCopy(buf, DEH_String(sfx->name), buf_len);
    }
}

static int Web_GetSfxLumpNum(sfxinfo_t *sfx)
{
    char namebuf[9];
    GetSfxLumpName(sfx, namebuf, sizeof(namebuf));
    return W_GetNumForName(namebuf);
}

static sfx_data_t *LoadSfx(sfxinfo_t *sfxinfo)
{
    sfx_data_t *result;
    byte *data;
    int lumpnum, lumplen;
    uint32_t length, rate;

    if (sfxinfo->driver_data != NULL)
    {
        return sfxinfo->driver_data;
    }

    lumpnum = sfxinfo->lumpnum;
    if (lumpnum < 0)
    {
        return NULL;
    }
    data = W_CacheLumpNum(lumpnum, PU_STATIC);
    lumplen = W_LumpLength(lumpnum);

    if (lumplen < 8 || data[0] != 0x03 || data[1] != 0x00)
    {
        return NULL;
    }

    rate = (data[3] << 8) | data[2];
    length = (data[7] << 24) | (data[6] << 16) | (data[5] << 8) | data[4];

    if (length > (uint32_t) lumplen - 8 || length <= 48)
    {
        return NULL;
    }

    result = malloc(sizeof(sfx_data_t));
    // DMX skips the first and last 16 bytes of sample data.
    result->samples = data + 8 + 16;
    result->length = length - 32;
    result->rate = rate ? rate : 11025;
    sfxinfo->driver_data = result;
    return result;
}

static void SetParams(channel_t *ch, int vol, int sep)
{
    // Same panning law as Chocolate Doom's SDL module.
    int left = ((254 - sep) * vol) / 127;
    int right = (sep * vol) / 127;
    if (left < 0) left = 0;
    if (right < 0) right = 0;
    if (left > 255) left = 255;
    if (right > 255) right = 255;
    ch->lvol = left;
    ch->rvol = right;
}

static boolean Web_InitSound(boolean _use_sfx_prefix)
{
    use_sfx_prefix = _use_sfx_prefix;
    memset(channels, 0, sizeof(channels));
    snd_samplerate = output_rate;
    sound_ok = true;
    return true;
}

static void Web_ShutdownSound(void)
{
    sound_ok = false;
}

static void Web_UpdateSound(void)
{
}

static void Web_UpdateSoundParams(int handle, int vol, int sep)
{
    if (handle < 0 || handle >= NUM_CHANNELS) return;
    SetParams(&channels[handle], vol, sep);
}

static int Web_StartSound(sfxinfo_t *sfxinfo, int channel, int vol, int sep, int pitch)
{
    sfx_data_t *sfx;
    channel_t *ch;

    if (channel < 0 || channel >= NUM_CHANNELS) return -1;

    sfx = LoadSfx(sfxinfo);
    if (sfx == NULL) return -1;

    ch = &channels[channel];
    ch->sfx = sfx;
    ch->pos = 0;
    {
        // Heretic/Hexen/Strife-style pitch variation; 127/128 is normal.
        double rate = sfx->rate;
        if (pitch > 0 && pitch != 127 && pitch != 128)
        {
            rate *= pow(2.0, (pitch - 128) / 64.0);
        }
        ch->step = (uint64_t) ((rate * 4294967296.0) / output_rate);
    }
    SetParams(ch, vol, sep);
    ch->active = 1;
    return channel;
}

static void Web_StopSound(int handle)
{
    if (handle < 0 || handle >= NUM_CHANNELS) return;
    channels[handle].active = 0;
}

static boolean Web_SoundIsPlaying(int handle)
{
    if (handle < 0 || handle >= NUM_CHANNELS) return false;
    return channels[handle].active;
}

static void Web_CacheSounds(sfxinfo_t *sounds, int num_sounds)
{
    // Sounds are loaded lazily on first use.
}

static snddevice_t sound_web_devices[] =
{
    SNDDEVICE_PCSPEAKER, SNDDEVICE_ADLIB, SNDDEVICE_SB, SNDDEVICE_PAS,
    SNDDEVICE_GUS, SNDDEVICE_WAVEBLASTER, SNDDEVICE_SOUNDCANVAS,
    SNDDEVICE_GENMIDI, SNDDEVICE_AWE32,
};

sound_module_t sound_web_module =
{
    sound_web_devices,
    arrlen(sound_web_devices),
    Web_InitSound,
    Web_ShutdownSound,
    Web_GetSfxLumpNum,
    Web_UpdateSound,
    Web_UpdateSoundParams,
    Web_StartSound,
    Web_StopSound,
    Web_SoundIsPlaying,
    Web_CacheSounds,
};

// Music: delegate to Chocolate Doom's OPL (AdLib/SB) emulation.

static boolean Web_InitMusic(void)
{
    snd_samplerate = output_rate;
    music_ok = music_opl_module.Init();
    return music_ok;
}
static void Web_ShutdownMusic(void) { if (music_ok) music_opl_module.Shutdown(); music_ok = false; }
static void Web_SetMusicVolume(int v) { if (music_ok) music_opl_module.SetMusicVolume(v); }
static void Web_PauseMusic(void) { if (music_ok) music_opl_module.PauseMusic(); }
static void Web_ResumeMusic(void) { if (music_ok) music_opl_module.ResumeMusic(); }
static void *Web_RegisterSong(void *data, int len) { return music_ok ? music_opl_module.RegisterSong(data, len) : NULL; }
static void Web_UnRegisterSong(void *h) { if (music_ok) music_opl_module.UnRegisterSong(h); }
static void Web_PlaySong(void *h, boolean looping) { if (music_ok) music_opl_module.PlaySong(h, looping); }
static void Web_StopSong(void) { if (music_ok) music_opl_module.StopSong(); }
static boolean Web_MusicIsPlaying(void) { return music_ok ? music_opl_module.MusicIsPlaying() : false; }

music_module_t music_web_module =
{
    sound_web_devices,
    arrlen(sound_web_devices),
    Web_InitMusic,
    Web_ShutdownMusic,
    Web_SetMusicVolume,
    Web_PauseMusic,
    Web_ResumeMusic,
    Web_RegisterSong,
    Web_UnRegisterSong,
    Web_PlaySong,
    Web_StopSong,
    Web_MusicIsPlaying,
    NULL,
};

// Called from the page's audio callback. Fills `frames` stereo frames.
EMSCRIPTEN_KEEPALIVE void web_audio_render(int16_t *out, int frames)
{
    int i, c;

    if (music_ok)
    {
        OPL_Web_Render(out, frames);
    }
    else
    {
        memset(out, 0, frames * 4);
    }

    if (!sound_ok)
    {
        return;
    }

    if (mixbuf_len < frames)
    {
        free(mixbuf);
        mixbuf = malloc(frames * 2 * sizeof(int32_t));
        mixbuf_len = frames;
    }

    for (i = 0; i < frames * 2; ++i)
    {
        mixbuf[i] = out[i];
    }

    for (c = 0; c < NUM_CHANNELS; ++c)
    {
        channel_t *ch = &channels[c];
        const sfx_data_t *sfx;
        if (!ch->active) continue;
        sfx = ch->sfx;

        for (i = 0; i < frames; ++i)
        {
            uint32_t idx = (uint32_t) (ch->pos >> 32);
            uint32_t frac;
            int s0, s1, s;

            if (idx >= sfx->length)
            {
                ch->active = 0;
                break;
            }

            // Linear interpolation between neighbouring samples.
            frac = (uint32_t) (ch->pos & 0xffffffffu) >> 16;
            s0 = (int) sfx->samples[idx] - 128;
            s1 = (idx + 1 < sfx->length) ? (int) sfx->samples[idx + 1] - 128 : s0;
            s = (s0 << 8) + (((s1 - s0) * (int) frac) >> 8);

            mixbuf[i * 2]     += (s * ch->lvol) >> 8;
            mixbuf[i * 2 + 1] += (s * ch->rvol) >> 8;

            ch->pos += ch->step;
        }
    }

    for (i = 0; i < frames * 2; ++i)
    {
        int32_t v = mixbuf[i];
        if (v > 32767) v = 32767;
        if (v < -32768) v = -32768;
        out[i] = (int16_t) v;
    }
}
