// Text-mode (textscreen) stubs: TXT_Init fails, so the games skip their
// DOS text startup screens and go straight to graphics.
#include <stddef.h>
#include <stdarg.h>
#include <stdio.h>
#include "txt_main.h"
#include "txt_io.h"
static unsigned char screen[4000];
int TXT_Init(void) { return 0; }
void TXT_Shutdown(void) {}
unsigned char *TXT_GetScreenData(void) { return screen; }
void TXT_UpdateScreenArea(int x, int y, int w, int h) {}
void TXT_UpdateScreen(void) {}
int TXT_GetChar(void) { return -1; }
void TXT_PutChar(int c) {}
void TXT_Puts(const char *s) {}
void TXT_GotoXY(int x, int y) {}
void TXT_GetXY(int *x, int *y) { *x = 0; *y = 0; }
void TXT_FGColor(txt_color_t color) {}
void TXT_BGColor(int color, int blinking) {}
void TXT_ClearScreen(void) {}
