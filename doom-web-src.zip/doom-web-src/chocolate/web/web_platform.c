// Page-facing entry points for the Chocolate Doom based engines
// (Heretic, Hexen, Strife). Build with -DWEB_GAME_HERETIC, _HEXEN or _STRIFE.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <emscripten.h>

#include "doomtype.h"
#include "d_event.h"
#include "d_mode.h"
#include "m_argv.h"
#include "m_config.h"

#if defined(WEB_GAME_HERETIC) || defined(WEB_GAME_HEXEN)
extern boolean MenuActive;
#define WEB_MENU_ACTIVE MenuActive
#else
extern boolean menuactive;
#define WEB_MENU_ACTIVE menuactive
#endif

#if defined(WEB_GAME_HEXEN)
#include "h2def.h"
#else
#include "doomdef.h"
#endif
#if defined(WEB_GAME_STRIFE)
#include "doomstat.h"
#endif

void D_DoomMain(void);
void M_FindResponseFile(void);

EMSCRIPTEN_KEEPALIVE int web_key_down(int gamekey, int menukey, int ch)
{
    event_t ev;
    int key = WEB_MENU_ACTIVE ? menukey : gamekey;

    memset(&ev, 0, sizeof(ev));
    ev.type = ev_keydown;
    ev.data1 = key;
    ev.data2 = ch ? ch : key;   // "localized" key, used by cheats
    ev.data3 = ch;              // typed character, used for text entry
    D_PostEvent(&ev);
    return key;
}

EMSCRIPTEN_KEEPALIVE void web_key_up(int key)
{
    event_t ev;

    memset(&ev, 0, sizeof(ev));
    ev.type = ev_keyup;
    ev.data1 = key;
    D_PostEvent(&ev);
}

EMSCRIPTEN_KEEPALIVE void web_mouse(int buttons, int dx, int dy)
{
    event_t ev;

    if (WEB_MENU_ACTIVE)
    {
        return;
    }

    memset(&ev, 0, sizeof(ev));
    ev.type = ev_mouse;
    ev.data1 = buttons;
    ev.data2 = dx;
    ev.data3 = dy;
    D_PostEvent(&ev);
}

EMSCRIPTEN_KEEPALIVE int web_menu_active(void)
{
    return WEB_MENU_ACTIVE;
}

EMSCRIPTEN_KEEPALIVE int web_wants_mouse(void)
{
    return gamestate == GS_LEVEL && !WEB_MENU_ACTIVE && !demoplayback
        && !paused;
}

EMSCRIPTEN_KEEPALIVE void web_save_config(void)
{
    M_SaveDefaults();
}

// The game loop runs by itself (yielding via Asyncify); nothing to do here.
EMSCRIPTEN_KEEPALIVE void web_frame(void)
{
}

EMSCRIPTEN_KEEPALIVE void web_start(const char *args)
{
    static char *argv[64];
    char *copy = strdup(args);
    char *p = copy;
    int argc = 0;

    argv[argc++] = "chocolate";
    while (*p && argc < 63)
    {
        char *nl = strchr(p, '\n');
        argv[argc++] = p;
        if (nl == NULL)
        {
            break;
        }
        *nl = '\0';
        p = nl + 1;
    }
    argv[argc] = NULL;

    myargc = argc;
    myargv = argv;
    M_FindResponseFile();

    // Never returns; the first sleep hands control back to the page.
    D_DoomMain();
}
