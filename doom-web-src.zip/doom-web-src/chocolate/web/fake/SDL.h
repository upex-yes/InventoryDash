// Minimal stand-in for the few SDL facilities the browser build still uses.
#ifndef WEB_FAKE_SDL_H
#define WEB_FAKE_SDL_H
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
typedef uint8_t Uint8; typedef int8_t Sint8;
typedef uint16_t Uint16; typedef int16_t Sint16;
typedef uint32_t Uint32; typedef int32_t Sint32;
typedef uint64_t Uint64; typedef int64_t Sint64;
#define SDL_LIL_ENDIAN 1234
#define SDL_BIG_ENDIAN 4321
#define SDL_BYTEORDER SDL_LIL_ENDIAN
#define SDL_SwapLE16(x) ((Uint16)(x))
#define SDL_SwapLE32(x) ((Uint32)(x))
#define SDL_SwapBE16(x) __builtin_bswap16((Uint16)(x))
#define SDL_SwapBE32(x) __builtin_bswap32((Uint32)(x))
#define SDL_INIT_TIMER 0x1
#define SDL_MESSAGEBOX_ERROR 0x10
Uint32 SDL_GetTicks(void);
void SDL_Delay(Uint32 ms);
static inline int SDL_Init(Uint32 f) { (void) f; return 0; }
static inline void SDL_Quit(void) {}
static inline int SDL_ShowSimpleMessageBox(Uint32 f, const char *t, const char *m, void *w)
{ (void) f; (void) t; (void) m; (void) w; return 0; }
static inline char *SDL_GetPrefPath(const char *org, const char *app)
{ (void) org; (void) app; return strdup("./"); }
#endif
