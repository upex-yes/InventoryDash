// Browser replacements for Chocolate Doom's SDL-based video, input,
// joystick, timer and misc platform modules (shared by Heretic, Hexen
// and Strife builds).

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <emscripten.h>

#include "config.h"
#include "doomtype.h"
#include "d_event.h"
#include "i_input.h"
#include "i_joystick.h"
#include "i_system.h"
#include "i_timer.h"
#include "i_video.h"
#include "i_videohr.h"
#include "i_endoom.h"
#include "m_argv.h"
#include "m_config.h"
#include "tables.h"
#include "v_video.h"
#include "w_wad.h"
#include "z_zone.h"
#include "net_defs.h"
#include "SDL.h"

// ---------------------------------------------------------------- timer

Uint32 SDL_GetTicks(void)
{
    static double base = -1;
    double now = emscripten_get_now();
    if (base < 0) base = now;
    return (Uint32) (now - base);
}

void SDL_Delay(Uint32 ms)
{
    // Yields to the browser (Asyncify) so the page stays responsive.
    emscripten_sleep(ms);
}

// ---------------------------------------------------------------- video

pixel_t *I_VideoBuffer = NULL;
boolean screensaver_mode = false;
boolean screenvisible = true;
int usegamma = 0;
unsigned int joywait = 0;
int usemouse = 1;
int png_screenshots = 0;
char *video_driver = "";
char *window_position = "center";
int video_display = 0;
int window_width = 640, window_height = 480;
int fullscreen_width = 0, fullscreen_height = 0;
int fullscreen = false;
int aspect_ratio_correct = true;
int integer_scaling = false;
int vga_porch_flash = false;
int force_software_renderer = false;
int screen_width = SCREENWIDTH, screen_height = SCREENHEIGHT;

static struct { byte r, g, b; } palette[256];
static uint32_t rgb_palette[256];
static uint32_t *rgb_buffer = NULL;
static grabmouse_callback_t grabmouse_callback = NULL;
static double last_yield = 0;

void I_InitGraphics(void)
{
    byte *doompal;

    I_VideoBuffer = Z_Malloc(SCREENWIDTH * SCREENHEIGHT, PU_STATIC, NULL);
    memset(I_VideoBuffer, 0, SCREENWIDTH * SCREENHEIGHT);
    V_RestoreBuffer();
    rgb_buffer = malloc(SCREENWIDTH * SCREENHEIGHT * 4);

    doompal = W_CacheLumpName("PLAYPAL", PU_CACHE);
    I_SetPalette(doompal);
    I_AtExit(I_ShutdownGraphics, true);
}

void I_GraphicsCheckCommandLine(void) {}
void I_ShutdownGraphics(void) {}
void I_CheckIsScreensaver(void) {}
void I_InitWindowTitle(void) {}
void I_InitWindowIcon(void) {}
void I_DisplayFPSDots(boolean dots_on) {}
void I_EnableLoadingDisk(int xoffs, int yoffs) {}
void I_BeginRead(void) {}
void I_UpdateNoBlit(void) {}
void I_StartFrame(void) {}
void I_GetWindowPosition(int *x, int *y, int w, int h) { *x = 0; *y = 0; }

void I_SetGrabMouseCallback(grabmouse_callback_t func)
{
    grabmouse_callback = func;
}

EMSCRIPTEN_KEEPALIVE int web_grab_mouse_wanted(void)
{
    return grabmouse_callback != NULL && grabmouse_callback();
}

void I_SetWindowTitle(char *title)
{
    EM_ASM({ if (Module.webTitle) Module.webTitle(UTF8ToString($0)); }, title);
}

void I_SetPalette(byte *doompalette)
{
    int i;

    for (i = 0; i < 256; ++i)
    {
        palette[i].r = gammatable[usegamma][*doompalette++] & ~3;
        palette[i].g = gammatable[usegamma][*doompalette++] & ~3;
        palette[i].b = gammatable[usegamma][*doompalette++] & ~3;
        rgb_palette[i] = (palette[i].r << 16) | (palette[i].g << 8)
                       | palette[i].b;
    }
}

int I_GetPaletteIndex(int r, int g, int b)
{
    int best = 0, best_diff = INT_MAX, diff, i;

    for (i = 0; i < 256; ++i)
    {
        diff = (r - palette[i].r) * (r - palette[i].r)
             + (g - palette[i].g) * (g - palette[i].g)
             + (b - palette[i].b) * (b - palette[i].b);
        if (diff < best_diff)
        {
            best = i;
            best_diff = diff;
        }
        if (diff == 0)
        {
            break;
        }
    }
    return best;
}

void I_FinishUpdate(void)
{
    int i;
    double now;

    if (I_VideoBuffer == NULL || rgb_buffer == NULL)
    {
        return;
    }

    for (i = 0; i < SCREENWIDTH * SCREENHEIGHT; ++i)
    {
        rgb_buffer[i] = rgb_palette[I_VideoBuffer[i]];
    }

    EM_ASM({ if (Module.webDraw) Module.webDraw($0); }, rgb_buffer);

    // Loops that redraw without sleeping (startup screens, finales)
    // still need to hand control back to the browser now and then.
    now = emscripten_get_now();
    if (now - last_yield > 50)
    {
        last_yield = now;
        emscripten_sleep(0);
    }
}

void I_ReadScreen(pixel_t *scr)
{
    memcpy(scr, I_VideoBuffer, SCREENWIDTH * SCREENHEIGHT * sizeof(*scr));
}

void I_StartTic(void)
{
    // Input arrives through web_key_down / web_key_up / web_mouse.
    // Make sure the browser gets a chance to deliver it.
    double now = emscripten_get_now();
    if (now - last_yield > 50)
    {
        last_yield = now;
        emscripten_sleep(0);
    }
}

void I_BindVideoVariables(void)
{
    M_BindIntVariable("use_mouse", &usemouse);
    M_BindIntVariable("usegamma", &usegamma);
}

// ---------------------------------------------------------------- input

float mouse_acceleration = 2.0;
int mouse_threshold = 10;
int vanilla_keyboard_mapping = true;
int novert = 1;

void I_BindInputVariables(void)
{
    M_BindFloatVariable("mouse_acceleration", &mouse_acceleration);
    M_BindIntVariable("mouse_threshold", &mouse_threshold);
}

void I_ReadMouse(void) {}
void I_StartTextInput(int x1, int y1, int x2, int y2) {}
void I_StopTextInput(void) {}

// ---------------------------------------------------------------- joystick

void I_InitJoystick(void) {}
void I_ShutdownJoystick(void) {}
void I_UpdateJoystick(void) {}
void I_BindJoystickVariables(void) {}

// ---------------------------------------------------------------- hi-res startup screens (Heretic/Hexen)

boolean I_SetVideoModeHR(void) { return false; }
void I_UnsetVideoModeHR(void) {}
void I_SetWindowTitleHR(char *title) {}
void I_ClearScreenHR(void) {}
void I_SlamBlockHR(int x, int y, int w, int h, const byte *src) {}
void I_SlamHR(const byte *buffer) {}
void I_InitPaletteHR(void) {}
void I_SetPaletteHR(const byte *palette) {}
void I_FadeToPaletteHR(const byte *palette) {}
void I_BlackPaletteHR(void) {}
boolean I_CheckAbortHR(void) { return false; }

// ---------------------------------------------------------------- misc

void I_Endoom(byte *data) {}

void NET_WaitForLaunch(void) {}

static boolean NetFail(void) { return false; }
static void NetSend(net_addr_t *addr, net_packet_t *packet) {}
static boolean NetRecv(net_addr_t **addr, net_packet_t **packet) { return false; }
static void NetAddrToString(net_addr_t *addr, char *buffer, int len)
{
    if (len > 0) buffer[0] = '\0';
}
static void NetFree(net_addr_t *addr) {}
static net_addr_t *NetResolve(char *addr) { return NULL; }

net_module_t net_sdl_module =
{
    NetFail, NetFail, NetSend, NetRecv, NetAddrToString, NetFree, NetResolve,
};
