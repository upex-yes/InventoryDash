#!/bin/bash
# link.sh <game>  -> out/<game>.js
cd ~/doom/build2; g=$1; mkdir -p out
COMMON=$(ls obj/common/*.o)
if [ "$g" = "hexen" ]; then COMMON=$(ls obj/common/*.o | grep -v "/deh_\(io\|main\|mapping\|text\)\.o"); fi
emcc -O2 $COMMON obj/$g/*.o -o out/$g.js --no-entry -lidbfs.js \
  -s ASYNCIFY=1 -s ASYNCIFY_STACK_SIZE=131072 \
  -s MODULARIZE=1 -s EXPORT_NAME=create_$g -s SINGLE_FILE=1 -s ENVIRONMENT=web \
  -s EXIT_RUNTIME=0 -s ALLOW_MEMORY_GROWTH=1 -s INITIAL_MEMORY=67108864 -s TOTAL_STACK=5242880 -s FORCE_FILESYSTEM=1 \
  -s "EXPORTED_RUNTIME_METHODS=['FS','IDBFS']" \
  -s "EXPORTED_FUNCTIONS=['_malloc','_free','_web_start','_web_key_down','_web_key_up','_web_mouse','_web_menu_active','_web_wants_mouse','_web_save_config','_web_frame','_web_audio_render','_web_set_samplerate']" $EXTRA
