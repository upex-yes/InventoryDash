#!/bin/bash
# Double-click to play: serves this folder and opens the page.
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then exec python3 serve.py
else echo "Python 3 is needed. Install it from https://www.python.org/downloads/ and try again."; read -r -p "Press Return to close."; fi
