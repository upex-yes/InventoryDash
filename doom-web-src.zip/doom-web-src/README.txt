Doom-engine web port source (GPLv2)

doom/: Doom engine = doomgeneric (github.com/ozkl/doomgeneric) + Chocolate Doom OPL music. Build: cc.sh for each name in srcs.txt, then link.sh.
chocolate/: Heretic, Hexen, Strife = Chocolate Doom 3.0.1 (github.com/chocolate-doom/chocolate-doom) with SDL replaced by browser shims in web/ (video, input, sound, OPL driver, stubs). Build: cc.sh, then link.sh heretic|hexen|strife. Uses Emscripten 3.1.6 with Asyncify.
Page: cat css_part.html body_part.html > template.html; python3 build.py
