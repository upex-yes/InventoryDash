cd ~/doom/build
for s in "$@"; do emcc -O2 -DFEATURE_SOUND -DDOOMGENERIC_RESX=320 -DDOOMGENERIC_RESY=200 -w -c $s.c -o obj/$s.o || exit 1; done
