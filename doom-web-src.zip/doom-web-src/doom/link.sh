set -e
cd ~/doom/build
emcc -O2 obj/*.o -o doom.js -lidbfs.js -s MODULARIZE=1 -s EXPORT_NAME=createDoom -s SINGLE_FILE=1 -s ENVIRONMENT=web --no-entry -s EXIT_RUNTIME=0 -s ALLOW_MEMORY_GROWTH=1 -s INITIAL_MEMORY=67108864 -s FORCE_FILESYSTEM=1 -s "EXPORTED_RUNTIME_METHODS=['FS','IDBFS','UTF8ToString']" -s "EXPORTED_FUNCTIONS=['_malloc','_web_start','_free','_web_key_down','_web_key_up','_web_mouse','_web_menu_active','_web_wants_mouse','_web_save_config','_web_frame','_web_audio_render','_web_set_samplerate']"
